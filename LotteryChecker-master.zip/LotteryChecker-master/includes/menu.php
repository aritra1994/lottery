<div class="container well">
  <div class="centered page-header">
    <h1 class="container header">Lottery Checker</h1>
    <nav class="navbar navbar-default ">
	    <ul class="nav navbar-nav">
	      <li><a href="bund.php">Bundles</a></li>
	      <li><a href="addBund.php">Add Bundle</a></li>
	      <li><a href="checkBund.php">Match Draw</a></li>
	    </ul>
	</nav>
  </div>
</div>